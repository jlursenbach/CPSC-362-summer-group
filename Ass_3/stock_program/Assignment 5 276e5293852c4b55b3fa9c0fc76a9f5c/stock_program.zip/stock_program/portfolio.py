#!/usr/bin/env python3

from module import main as pr

def main():
  pr.main()
 
 #working

if __name__ == '__main__':
  main()
